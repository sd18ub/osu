# AIM LABORATORY



## Description

AIM LABORATORY est un jeu de tir ciblé conçu pour aider à améliorer la précision et la réactivité des joueurs. Le jeu propose différents niveaux de difficulté avec des cibles qui peuvent rester stationnaires ou se déplacer. Les performances des joueurs sont suivies et affichées à la fin de chaque session de jeu, incluant la précision,le score total et le temps.

## Fonctionnalité

Différents niveaux de difficulté.
Cibles mouvantes pour augmenter la difficulté.
Statistiques de performance à la fin de chaque session.
Menu principal pour démarrer ou quitter le jeu.
Menu de fin de session avec option pour retourner au menu principal ou quitter.


## Prérequis

Le jeu nécessite les bibliothèques suivantes :

Grapic

## Compilation 

Pour compiler le jeu, vous pouvez utiliser g++ ou un autre compilateur C++ qui supporte C++11 ou plus récent.
``` bash
g++ -o AIMLAB main.cpp -lgrapic
```
Remplacez main.cpp par le chemin d'accès à votre fichier source principal.

## Execution
Une fois compilé, vous pouvez lancer le jeu en utilisant :
``` bash
./AIMLAB
```

## Avancé par semaine
Semaine 1 :

  - Création des menues pour lancer le jeu/quitter
  - Création des menues de fin de jeu pour relancer le jeu/quitter

Semaine 2 : 

  - Creation du jeu et appartion des cibles pour le premier niveau
  - Spawn aléatoires des cibles et disparition au bout d'un certain temps donné par le niveau de difficulté choisis
  - Affichage des differentes stats de la partie comme le temps de la partie et le score

Semaine 3 :

  - Ajout du calcul de precision
  - Affichage de la precision dans le menue de fin de partie

SOON :

  - lancer le jeu permettra de changer son statue discord ce qui indiquera joue à "AIM lab"

## Screen
![App Scrennchot](/grapic_1.png)
![App Scrennchot](/grapic_2.png)
![App Scrennchot](/grapic_0.png)


()
[MIT](https://choosealicense.com/licenses/mit/)